#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include "Memory.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <glm\ext\vector_float4.hpp>
#include "GameState.h"
#include <string>
#include "Regex.h"

std::string resource_load_text_file(std::string filePath)
{
	std::ifstream myFile(filePath);
	std::stringstream myStream;
	myStream << myFile.rdbuf();
	myFile.close();

	std::string result = myStream.str();
	return result;
}

unsigned int resource_load_image_from_file_onto_gpu(std::string file_path)
{
	unsigned int result;
	glGenTextures(1, &result);
	glEnable(GL_BLEND);
	glBindTexture(GL_TEXTURE_2D, result);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.

	int width;
	int height;
	int num_of_channels;
	unsigned char* data = stbi_load(file_path.c_str(), &width, &height, &num_of_channels, 0);

	if (data)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		//glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Texture load failed, name of file:" << file_path.c_str() << "looks like the programs gonna crash now" << std::endl;
	}
	stbi_image_free(data);

	return result;
}

glm::vec4* resource_load_texcoords_pieces(Memory* memory, Memory* tempMemory)
{
	float totalW = 204;
	float totalH = 66;
	float* conversion = (float*)memory_alloc(memory, sizeof(float) * 4 * F_COUNT);
	//none P_NONE
	conversion[0] = 70;
	conversion[1] = 2;
	conversion[2] = 64;
	conversion[3] = 64;
	//player P_PLAYER
	conversion[4] = 138;
	conversion[5] = 2;
	conversion[6] = 64;
	conversion[7] = 64;
	//crate P_CRATE
	conversion[8] = 2;
	conversion[9] = 2;
	conversion[10] = 64;
	conversion[11] = 64;
	for (int i = 0; i < 12; i += 4)
	{
		conversion[i + 2] += conversion[i];
		conversion[i + 3] += conversion[i + 1];
		conversion[i] /= totalW;
		conversion[i + 1] /= totalH;
		conversion[i + 2] /= totalW;
		conversion[i + 3] /= totalH;
	}
	return (glm::vec4*) conversion;
}
/*
glm::vec4* resource_load_texcoords_floor(Memory* memory, Memory* tempMemory)
{
	int totalW = 512;
	int totalH = 128;
	int* start = (int*)memory_alloc(tempMemory, sizeof(int) * 4 * F_COUNT);
	float* conversion = (float*) memory_alloc(memory, sizeof(float) * 4 * F_COUNT);
	//floor. F_NONE
	start[0] = 2.0f;
	start[1] = 2.0f;
	start[2] = 64.0f;
	start[3] = 64.0f;
	//target. F_TARGET
	start[4] = 138;
	start[5] = 2;
	start[6] = 64;
	start[7] = 64;
	//wall. F_WALL
	start[8] = 206;
	start[9] = 2;
	start[10] = 64;
	start[11] = 64;
	//outline. F_OUTLINE
	start[12] = 70;
	start[13] = 2;
	start[14] = 64;
	start[15] = 64;
	//outline. F_BLACK
	start[16] = 274;
	start[17] = 2;
	start[18] = 64;
	start[19] = 64;
	std::cout << "FLOOR CONVERSION!" << std::endl;
	for (int i = 0; i < F_COUNT * 4; i += 4)
	{
		//flip the starting coordinates into our actual coordinate system.
		start[i + 1] = totalH - 1 - start[i + 1];
		start[i + 1] -= start[i + 3] - 1;

		//turn w/h into x2/y2
		start[i + 2] += start[i] - 1;
		start[i + 3] += start[i + 1] - 1;

		conversion[i] = start[i];
		conversion[i + 1] = start[i + 1];
		conversion[i + 2] = start[i + 2];
		conversion[i + 3] = start[i + 3];

		//convert from int to floats between 0 and 1
		conversion[i] = conversion[i] / (totalW - 1);
		conversion[i + 1] /= (totalH - 1);
		conversion[i + 2] /= (totalW - 1);
		conversion[i + 3] /= (totalH - 1);

		std::cout << conversion[i] << "," << conversion[i] * totalW << std::endl;
		std::cout << conversion[i + 1] << "," << conversion[i + 1] * totalH << std::endl;
		std::cout << conversion[i + 2] << "," << conversion[i + 2] * totalW <<std::endl;
		std::cout << conversion[i + 3] << "," << conversion[i + 3] * totalH << std::endl;
		std::cout << "next" << std::endl;
	}

	return (glm::vec4*) conversion;
}
*/

glm::vec4* resource_load_texcoords_floor_old(Memory* memory)
{
	float totalW = 512;
	float totalH = 128;
	float* conversion = (float*)memory_alloc(memory, sizeof(float) * 4 * F_COUNT);
	//floor. F_NONE
	conversion[0] = 2.0f;
	conversion[1] = 2.0f;
	conversion[2] = 64.0f;
	conversion[3] = 64.0f;
	//target. F_TARGET
	conversion[4] = 138;
	conversion[5] = 2;
	conversion[6] = 64;
	conversion[7] = 64;
	//wall. F_WALL
	conversion[8] = 206;
	conversion[9] = 2;
	conversion[10] = 64;
	conversion[11] = 64;
	//outline. F_OUTLINE
	conversion[12] = 70;
	conversion[13] = 2;
	conversion[14] = 64;
	conversion[15] = 64;
	std::cout << "FLOOR CONVERSION!" << std::endl;
	for (int i = 0; i < 16; i += 4)
	{
		//flip the starting coordinates into our actual coordinate system.
		conversion[i + 1] = totalH - 1 - conversion[i + 1];
		conversion[i + 1] -= conversion[i + 3] - 1;

		//turn w/h into x2/y2
		conversion[i + 2] += conversion[i] - 1;
		conversion[i + 3] += conversion[i + 1] - 1;

		//convert from int to floats between 0 and 1
		conversion[i] = conversion[i] / (totalW - 1);
		conversion[i + 1] /= (totalH - 1);
		conversion[i + 2] /= (totalW - 1);
		conversion[i + 3] /= (totalH - 1);

		std::cout << conversion[i] << "," << conversion[i] * totalW << std::endl;
		std::cout << conversion[i + 1] << "," << conversion[i + 1] * totalH << std::endl;
		std::cout << conversion[i + 2] << "," << conversion[i + 2] * totalW << std::endl;
		std::cout << conversion[i + 3] << "," << conversion[i + 3] * totalH << std::endl;
		std::cout << "next" << std::endl;
	}

	return (glm::vec4*) conversion;
}


glm::vec4* resource_load_texcoords_floor(Memory* memory, Memory* tempMemory)
{
	std::string file = resource_load_text_file("temp.json");
	AtlasData* data = GetAtlasPosition(memory, file);

	glm::vec4* result = (glm::vec4*) memory_alloc(memory, sizeof(glm::vec4) * data->length);
	int totalH = data->metaHeight;
	int totalW = data->metaWidth;

	for (int i = 0; i < data->length; i++)
	{
		Position p = data->positions[i];
		//flip the starting coordinates into our actual coordinate system.
		p.y = totalH - 1 - p.y;
		p.y -= p.h - 1;

		//turn w/h into x2/y2
		p.w += p.x - 1;
		p.h += p.y - 1;

		int next_index = data->enum_corrospoding_values[i];
		//convert from int to floats between 0 and 1
		result[next_index].x = (float) p.x / (totalW - 1);
		result[next_index].y = (float) p.y / (totalH - 1);
		result[next_index].z = (float) p.w / (totalW - 1);
		result[next_index].w = (float) p.h / (totalH - 1);
	}

	glm::vec4* old = resource_load_texcoords_floor_old(memory);

	for (int i = 0; i < data->length; i++)
	{
		std::cout << result[i].x << std::endl;
		std::cout << old[i].x << std::endl;
	}
	return result;
}
//old

