#pragma once

#define MAX_EDITOR_ACTIONS 100000
#define MAX_NUMBER_GAMESTATES 1000

#include "Memory.h"
#include "Math.h"


enum Piece {
	P_NONE,
	P_PLAYER,
	P_CRATE,
	P_COUNT
};

enum Floor {
	F_NONE,
	F_TARGET,
	F_WALL,
	F_OUTLINE,
	F_BLACK,
	F_COUNT
};
struct GameState {
	int w;
	int h;
	int** layers;
};

struct GamestateBrush {
	bool applyFloor;
	bool applyPiece;
	Floor floor;
	Piece piece;
};

struct GamestateTimeMachine
{
	GameState* start_state;
	GameState* state_array;
	int num_gamestates_stored;
	int max_gamestates_storable;
};
enum Direction {
	U,R,D,L
};

/*****************************GAMESTATE TIME MACHINE******************/
/*********************************************************************/
GamestateTimeMachine* gamestate_timemachine_create(GameState* start_state, Memory* memory, int max_num_gamestates);
void gamestate_timemachine_take_action(GamestateTimeMachine* timeMachine, Direction action, Memory* scope_memory, Memory* temp_memory);
/*************************PALETTE_BRUSH*******************************/
/*********************************************************************/
GamestateBrush gamestate_brush_create(bool applyFloor, Floor floor, bool applyPiece, Piece piece);

/******************************GAMESTATE WRITE************************/
/*********************************************************************/

GameState* gamestate_create(Memory* memory, int w, int h);
GameState* gamestate_clone(GameState* state, Memory* memory);
void gamestate_clone_to_unitialized(GameState* input, GameState* output, Memory* memory);
void  gamestate_clone_to(GameState* input_state, GameState* output_state);

void gamestate_resize(GameState* input_state, GameState* output_state, IntPair displacement_from_input_to_output);
GameState* gamestate_resize_with_allocate(GameState* input_state, Memory* output_memory, int output_w, int output_h, IntPair displacement_from_input_to_output);
void gamestate_apply_brush(GameState* state, GamestateBrush brush, int x, int y);
GameState* gamestate_merge_with_allocate(GameState* first, GameState* second, IntPair combined_size, Memory* output_memory, IntPair left_merge_offset, IntPair right_merge_offset);
void gamestate_merge(GameState* left, GameState* right, GameState* output, IntPair left_merge_offset, IntPair right_merge_offset);

/******************************GAMESTATE READ************************/
/********************************************************************/

bool gamestate_eq(GameState* left, GameState* right);
//unsigned int gamestate_player_find(GameState* gamestate);
AABB* gamestate_create_colliders(Memory* memory, GameState** states, IntPair* locations, int length);
AABB* gamestate_create_colliders(Memory* memory, GameState** states, IntPair* locations, int length, int skip_index);

/******************************GAMESTATE WRITE**********************/
/********************************************************************/

void gamestate_action(GameState* state, Direction action, Memory* temp_memory);