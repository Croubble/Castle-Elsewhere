#pragma once
#include "Memory.h"
#include <regex>

struct Position
{
	int x;
	int y;
	int w;
	int h;
};

struct str
{
	int length;
	char* val;
};

struct AtlasData
{
	int metaWidth;
	int metaHeight;
	int length;
	int* enum_corrospoding_values;
	Position* positions;
};

int resource_texturenames_to_floorenum_names_internal(std::string s)
{
	if (s == "Floor.png")
		return F_NONE;
	if (s == "Outline.png")
		return F_OUTLINE;
	if (s == "Target.png")
		return F_TARGET;
	if (s == "Wall.png")
		return F_WALL;
	if (s == "ZBlack.png")
		return F_BLACK;
	std::cout << "UH OH! UH OH! UH OH! WE GOT A PROBLEM in resource_texturenames_to_floorenum_names_internal ZZZZZZZZZZZZZZZ all hail doggo's!." << std::endl;
	return F_NONE;
}

AtlasData* GetAtlasPosition(Memory* memory, std::string atlas)
{
	AtlasData* result = (AtlasData*)memory_alloc(memory, sizeof(AtlasData));

	result->length = 0;
	try {
		//step 1: get the length.
		std::regex filename_regex("filename\": \"(.*)\",");
		{
			std::sregex_iterator next(atlas.begin(), atlas.end(), filename_regex);
			std::sregex_iterator end;
			while (next != end)
			{
				std::smatch match = *next;
				result->length++;
				next++;
			}
		}
		//step 1a: get the filenames converted into enums.
		result->enum_corrospoding_values = (int*)memory_alloc(memory, sizeof(int) * result->length);
		{
			int num_index = 0;
			std::sregex_iterator next(atlas.begin(), atlas.end(), filename_regex);
			std::sregex_iterator end;
			while (next != end)
			{
				std::smatch match = *next;
				std::string name = match.str(1);
				result->enum_corrospoding_values[num_index] = resource_texturenames_to_floorenum_names_internal(name);
				num_index++;
				next++;
			}
		}

		result->positions = (Position*)memory_alloc(memory, sizeof(Position) * result->length);
		int index = 0;
		//step 2: get all the width, height, position, heights.
		std::regex data_regex("\"frame\": .\"x\":([0-9]+),\"y\":([0-9]+),\"w\":([0-9]+),\"h\":([0-9]+)");
		{
			std::sregex_iterator next(atlas.begin(), atlas.end(), data_regex);
			std::sregex_iterator end;
			while (next != end)
			{
				std::smatch match = *next;
				std::string x = match.str(1);
				std::string y = match.str(2);
				std::string w = match.str(3);
				std::string h = match.str(4);

				result->positions[index].x = std::stoi(x);
				result->positions[index].y = std::stoi(y);
				result->positions[index].w = std::stoi(w);
				result->positions[index].h = std::stoi(h);

				index++;
				next++;
			}
		}
		//step 3: get the meta data.
		std::regex meta_regex("\"size\": .\"w\":([0-9]*),\"h\":([0-9]*)");
		{
			std::smatch match;
			if (std::regex_search(atlas, match, meta_regex) && match.size() > 1) {
				std::string w = match.str(1);
				std::string h = match.str(2);

				result->metaWidth = std::stoi(w);
				result->metaHeight = std::stoi(h);
			}
		}

		return result;

	}
	catch (std::regex_error& e) {
		//ehh.
	}
	return nullptr;
}
