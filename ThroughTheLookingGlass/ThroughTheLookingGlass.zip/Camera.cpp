#include "Math.h"
#include <glad/glad.h>
#include <glm\ext\vector_float2.hpp>




RealSpaceCamera math_gamespacecamera_to_realspacecamera(GameSpaceCamera camera, float gameHeight, int screenHeight, int screenWidth)
{
	RealSpaceCamera result;
	//okay so what we want to do is convert left, right, up, and down, all into the gamespace position, then we good!
	float ratio = ((float)screenHeight) / gameHeight;
	result.left = camera.left * ratio;
	result.right = camera.right * ratio;
	result.up = camera.up * ratio;
	result.down = camera.down * ratio;
	result.closePoint = camera.closePoint * ratio;
	result.farPoint = camera.farPoint * ratio;
	return result;
}
glm::vec2 math_screenspace_to_pixelspace(IntPair screenSpacePosition, GameSpaceCamera camera, ViewPortCamera view, float gameHeight)
{
	glm::vec2 result;
	result.x = screenSpacePosition.x + camera.left * view.up / gameHeight;
	result.y = screenSpacePosition.y + camera.down * view.up / gameHeight;
	return result;
}
glm::vec2 math_pixelspace_to_screenspace(IntPair pixelSpacePosition, GameSpaceCamera camera, ViewPortCamera view, float gameHeight)
{
	glm::vec2 result;
	result.x = pixelSpacePosition.x - camera.left * view.up / gameHeight;
	result.y = pixelSpacePosition.y - camera.down * view.up / gameHeight;
	return result;
}
glm::vec2 math_screenspace_to_gamespace(IntPair screenSpacePosition, GameSpaceCamera camera, ViewPortCamera view, float gameHeight)
{
	//convert screenspace to pixelspace.
	glm::vec2 pixelspace = math_screenspace_to_pixelspace(screenSpacePosition, camera, view, gameHeight);
	//convert pixelspace to gamespace.
	glm::vec2 result;
	float divide = math_gamespace_to_pixelspace_multiplier(view, gameHeight);
	result.x = pixelspace.x / divide;
	result.y = pixelspace.y / divide;
	//return gamespace.
	return result;
}
float math_gamespace_to_pixelspace_multiplier(ViewPortCamera view, float gameHeight)
{
	float yDist = view.up - view.down;
	float result = yDist / gameHeight;
	return result;
}
float math_pixelspace_to_gamespace_multiplier(ViewPortCamera view, float gameHeight)
{
	return 1 / math_gamespace_to_pixelspace_multiplier(view, gameHeight);
}


