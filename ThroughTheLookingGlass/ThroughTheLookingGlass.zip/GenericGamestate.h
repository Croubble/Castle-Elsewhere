#pragma once
#include <glm\ext\vector_float4.hpp>
#include "Memory.h"
#include "TextureAtlas.h"
#include <string>


enum LAYER_NAME
{
	LN_FLOOR,
	LN_PIECE,
	LN_COUNT
};
const int GAME_NUM_LAYERS = LN_COUNT;

struct GenericGame
{
	int num_layers;
	int* num_elements_in_layer;	//number of elements that occur in this layer per character.
	char*** element_names;	//okay so what we actually do is make a biiiig array and put all of em. ALL OF EM. In order.
};
struct GenericGamestate
{
	int w;
	int h;
	int** layers;
};




//gpu setup:
	//add textureAtlasMaps, a function that builds the texture atlas for
	//remove piece / floor, replace with general setup of algorithm that sets up N VAO's, where N is number of layers.
	//get old piece / floor to draw arbitrary textures.
	//