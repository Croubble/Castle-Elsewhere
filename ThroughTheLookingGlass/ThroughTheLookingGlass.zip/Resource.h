#pragma once

#include <string>
#include "Memory.h"
std::string resource_load_text_file(std::string filePath);
unsigned int resource_load_image_from_file_onto_gpu(std::string filePath);	//returns GLuint reference to gpu texture.
glm::vec4* resource_load_texcoords_floor(Memory* memory, Memory* tempMemory);
glm::vec4* resource_load_texcoords_pieces(Memory* memory, Memory* tempMemory);
